import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { NavLink, useNavigate, useParams } from 'react-router-dom'

const Productdetails = () => {
  const param = useParams()
  let { pid } = param;
  let navigate = useNavigate()
  let [product, setproduct] = useState({})
  let getdata = async () => {
    let fetchdata = await fetch(`https://fakestoreapi.com/products/${pid}`)
    let data = await fetchdata.json()
    setproduct(data)
  }
  useEffect(() => {
    getdata();
  }, [])
  let prev = () => {
    navigate(-1)
  }
  let addCart = async (product) => {

    let { id, ...rest } = product

    await axios.post("http://localhost:3000/items", rest)
    alert("product added")
  }
  return (
    <>
      <div className="main">

        <div className="pcards">
          <img src={product.image} alt="" className='img' />
          <h2>ProductName:{product.title}</h2>
          <h3>Price:{product.price}</h3>
          <h2>Description</h2>
          <p>{product.description}</p>

          {/* <h4>Rating:{product.rate.rating}</h4> */}
          <button onClick={()=>addCart(product)} className='btn2'>Add to cart</button>

        </div>

        <button onClick={prev} className='btn3'>Previous</button>
      </div>


    </>
  )
}

export default Productdetails
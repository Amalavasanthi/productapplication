import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';

const Signup = () => {
  let [UserName, setUsername] = useState("")
  let [UserPass, setUserPass] = useState("")
  let [UserEmail, setUserEmail] = useState("")
  let navigate = useNavigate()

  let handleSumbit = async (e) => {
    e.preventDefault()
    let payload = {
      Name: UserName,
      Pass: UserPass,
      Email: UserEmail
    }
    await axios.post("http://localhost:3000/users", payload);
    alert("signup done")
    setUsername("")
    setUserPass("")
    setUserEmail("")
    navigate("/login")

  }
  return (

    <>
      <div className='signup'>

        <div className="inner">
        <h2 className='h2'>Signup Page</h2>
          <form action="" onSubmit={handleSumbit}>
            <label htmlFor="">Name</label>
            <input type="text" placeholder='enter your name' value={UserName} onChange={(e) => setUsername(e.target.value)} />
            <label htmlFor="">Email</label>
            <input type="email" placeholder='enter your email' value={UserEmail} onChange={(e) => setUserEmail(e.target.value)} />
            <label htmlFor="">Password</label>
            <input type="password" placeholder='enter your password' value={UserPass} onChange={(e) => setUserPass(e.target.value)}/>
              <button >Register</button>
          </form>
          <footer>
            <p>Already have an Accout?</p>
            <Link to="/login">Login</Link>
          </footer>
        </div>
      </div></>
  )
}

export default Signup